import * as React from "react";
import { AuthContext } from "@/context/auth-provider";

export default function useAuth() {
  const context = React.useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used within a AuthProvider");
  }

  const { isAuthFetching, user } = context;

  return {
    isAuthFetching,
    user,
  };
}
