import useAuth from "@/hooks/apis/use-auth";

export default function ProfilePage() {
  const { user } = useAuth();

  if (!user) return <div>Loading...</div>;

  return (
    <div>
      <h2>{user.fullname}</h2>
      <p>{user.email}</p>
      <p>{user.phoneNumber}</p>
      <p>{user.role}</p>
      {/* Add more fields as needed */}
    </div>
  );
}
