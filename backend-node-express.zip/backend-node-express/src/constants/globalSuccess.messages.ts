export enum GlobalSuccessMessages {
  DEV_SERVER_STARTED = "Development server started successfully! 🎉",
  SERVER_STARTED = "Server is up and running! 🚀",
  MONGO_CONNECTION_SUCCESS = "Connected to MongoDB successfully! ✅",
}
